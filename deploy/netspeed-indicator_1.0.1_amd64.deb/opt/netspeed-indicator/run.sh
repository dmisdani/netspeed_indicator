python /opt/netspeed-indicator/netspeed-indicator2.py
